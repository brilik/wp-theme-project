<?php
/*
Plugin Name: ITDecision - Number Info
Description: Insert the absolute section with custom counters.
Version: 0.1.0
Author: ITDecision llc
Author URI: https://www.it-decision.com/
*/

include( plugin_dir_path( __FILE__ ) . 'inc/NumberInfo.php');

$info = new NumberInfo();

if (!is_admin()) {

    function number_info()
    {
        global $info;
        $info->render();
    }
}