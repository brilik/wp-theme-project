<?php

/**
 * Class NumberInfo
 * Create option page and function for show in front
 */

class NumberInfo
{
    private static $true_page = 'info_number.php';

    public function __construct()
    {
        add_action('admin_menu', array($this, 'create_page_options'));
        add_action( 'admin_init', array($this, 'create_option_settings') );
        add_action('wp_enqueue_scripts', array($this, 'enqueue'));
    }

    /**
     * Includes style/script for plugin
     */
    public function enqueue()
    {
        wp_enqueue_style('number-info', plugins_url('../assets/css/number-info.css', __FILE__));
    }

    /**
     * Render in front page
     */
    public function render()
    {
        $options = get_option('info_num_options');
        ?>
        <section class="number-info-wrapper">
            <div class="numbers-info">
                <div class="number-info__box">
                    <div class="box-num"><?= $options['num_info_one_number']; ?></div>
                    <div class="box-unit"><?= $options['num_info_one_unit']; ?></div>
                    <div class="box-detail"><?= $options['num_info_one_detail']; ?></div>
                </div>
                <div class="number-info__box">
                    <div class="box-num"><?= $options['num_info_two_number']; ?></div>
                    <div class="box-unit"><?= $options['num_info_two_unit']; ?></div>
                    <div class="box-detail"><?= $options['num_info_two_detail']; ?></div>
                </div>
                <div class="number-info__box">
                    <div class="box-num"><?= $options['num_info_three_number']; ?></div>
                    <div class="box-unit"><?= $options['num_info_three_unit']; ?></div>
                    <div class="box-detail"><?= $options['num_info_three_detail']; ?></div>
                </div>
                <div class="number-info__box">
                    <div class="box-num"><?= $options['num_info_four_number']; ?></div>
                    <div class="box-unit"><?= $options['num_info_four_unit']; ?></div>
                    <div class="box-detail"><?= $options['num_info_four_detail']; ?></div>
                </div>
            </div>
        </section>
        <?php
    }

    /**
     * Create page for options
     */
    public function create_page_options()
    {
        add_options_page(__('Setting Info Number'), __('Info number'), 'manage_options', self::$true_page, array($this, 'create_option_page'));
    }

    /**
     * Create settings page for plugin
     */
    public function create_option_page()
    {
        ?><div class="wrap">
        <h2><?= get_admin_page_title() ?></h2>
        <form method="post" enctype="multipart/form-data" action="options.php">
            <?php
            settings_fields('info_num_options');
            do_settings_sections(self::$true_page);
            submit_button();
            ?>
        </form>
        </div><?php
    }

    /**
     * Registration options and fields
     */
    public function create_option_settings() {
        register_setting( 'info_num_options', 'info_num_options', array($this,'field_validate_settings') );

        // Add section options
        $section_id = 'section_id_one';
        add_settings_section($section_id, __('First count info'), '', self::$true_page);

        $field_id = 'num_info_one_number';
        $params = array(
            'type' => 'number',
            'id' => $field_id,
            'desc' => 'Пример обычного текстового поля.',
            'label_for' => $field_id,
            'min' => 1,
            'max' => 5
        );
        add_settings_field($field_id, __('Number:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        $field_id = 'num_info_one_unit';
        $params = array(
            'type' => 'text',
            'id' => $field_id,
            'desc' => 'Пример большого текстового поля.',
            'label_for' => $field_id
        );
        add_settings_field($field_id, __('Unit:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        $field_id = 'num_info_one_detail';
        $params = array(
            'type' => 'text',
            'id' => $field_id,
            'desc' => 'Пример большого текстового поля.',
            'label_for' => $field_id
        );
        add_settings_field($field_id, __('Details:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        // Add section options
        $section_id = 'section_id_two';
        add_settings_section( $section_id, __('Second count info'), '', self::$true_page );

        $field_id = 'num_info_two_number';
        $params = array(
            'type' => 'number',
            'id' => $field_id,
            'desc' => 'Пример обычного текстового поля.',
            'label_for' => $field_id,
            'min' => 1,
            'max' => 5
        );
        add_settings_field($field_id, __('Number:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        $field_id = 'num_info_two_unit';
        $params = array(
            'type' => 'text',
            'id' => $field_id,
            'desc' => 'Пример большого текстового поля.',
            'label_for' => $field_id
        );
        add_settings_field($field_id, __('Unit:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        $field_id = 'num_info_two_detail';
        $params = array(
            'type' => 'text',
            'id' => $field_id,
            'desc' => 'Пример большого текстового поля.',
            'label_for' => $field_id
        );
        add_settings_field($field_id, __('Details:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        // Add section options
        $section_id = 'section_id_three';
        add_settings_section( $section_id, __('Third count info'), '', self::$true_page );

        $field_id = 'num_info_three_number';
        $params = array(
            'type' => 'number',
            'id' => $field_id,
            'desc' => 'Пример обычного текстового поля.',
            'label_for' => $field_id,
            'min' => 1,
            'max' => 5
        );
        add_settings_field($field_id, __('Number:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        $field_id = 'num_info_three_unit';
        $params = array(
            'type' => 'text',
            'id' => $field_id,
            'desc' => 'Пример большого текстового поля.',
            'label_for' => $field_id
        );
        add_settings_field($field_id, __('Unit:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        $field_id = 'num_info_three_detail';
        $params = array(
            'type' => 'text',
            'id' => $field_id,
            'desc' => 'Пример большого текстового поля.',
            'label_for' => $field_id
        );
        add_settings_field($field_id, __('Details:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        // Add section options
        $section_id = 'section_id_four';
        add_settings_section( $section_id, __('Fourth count info'), '', self::$true_page );

        $field_id = 'num_info_four_number';
        $params = array(
            'type' => 'number',
            'id' => $field_id,
            'desc' => 'Пример обычного текстового поля.',
            'label_for' => $field_id,
            'min' => 1,
            'max' => 5
        );
        add_settings_field($field_id, __('Number:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        $field_id = 'num_info_four_unit';
        $params = array(
            'type' => 'text',
            'id' => $field_id,
            'desc' => 'Пример большого текстового поля.',
            'label_for' => $field_id
        );
        add_settings_field($field_id, __('Unit:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);

        $field_id = 'num_info_four_detail';
        $params = array(
            'type' => 'text',
            'id' => $field_id,
            'desc' => 'Пример большого текстового поля.',
            'label_for' => $field_id
        );
        add_settings_field($field_id, __('Details:'), array($this, 'create_option_display_settings'), self::$true_page, $section_id, $params);
    }

    /**
     * Create field for options
     * @param $args
     */
    public function create_option_display_settings($args) {
        extract( $args );

        $option_name = 'info_num_options';

        $o = get_option( $option_name );

        switch ( $type ) {
            case 'text':
                $o[$id] = esc_attr( stripslashes($o[$id]) );
                echo "<input class='regular-text' type='text' id='$id' name='" . $option_name . "[$id]' value='$o[$id]' />";
                echo ($desc != '') ? "<br /><span class='description'>$desc</span>" : "";
                break;
            case 'textarea':
                $o[$id] = esc_attr( stripslashes($o[$id]) );
                echo "<textarea class='code large-text' cols='50' rows='10' type='text' id='$id' name='" . $option_name . "[$id]'>$o[$id]</textarea>";
                echo ($desc != '') ? "<br /><span class='description'>$desc</span>" : "";
                break;
            case 'checkbox':
                $checked = ($o[$id] == 'on') ? " checked='checked'" :  '';
                echo "<label><input type='checkbox' id='$id' name='" . $option_name . "[$id]' $checked /> ";
                echo ($desc != '') ? $desc : "";
                echo "</label>";
                break;
            case 'select':
                echo "<select id='$id' name='" . $option_name . "[$id]'>";
                foreach($vals as $v=>$l){
                    $selected = ($o[$id] == $v) ? "selected='selected'" : '';
                    echo "<option value='$v' $selected>$l</option>";
                }
                echo ($desc != '') ? $desc : "";
                echo "</select>";
                break;
            case 'radio':
                echo "<fieldset>";
                foreach($vals as $v=>$l){
                    $checked = ($o[$id] == $v) ? "checked='checked'" : '';
                    echo "<label><input type='radio' name='" . $option_name . "[$id]' value='$v' $checked />$l</label><br />";
                }
                echo "</fieldset>";
                break;
            case 'number':
                $o[$id] = esc_attr( stripslashes($o[$id]) );
                echo "<input class='regular-text' type='number' id='$id' name='" . $option_name . "[$id]' value='$o[$id]' width='10' />";
                echo ($desc != '') ? "<br /><span class='description'>$desc</span>" : "";
                break;
        }
    }

    /**
     * Validation fields
     * @param $input
     * @return mixed
     */
    public function field_validate_settings($input) {
        foreach($input as $k => $v) {
            $valid_input[$k] = trim($v);
            /*
            if(!) {
                $valid_input[$k] = '';
            }
            */
        }
        return $valid_input;
    }

}