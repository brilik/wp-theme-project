<?php
// golden edition